<!DOCTYPE html>
        <html lang="pt-br">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta name="theme-color" content="#141415">
            <title>CECS_VIBE_APK</title>
            <!-- bootstrap css -->
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
            <!-- bootstrap icons -->
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
            <!-- sweetalert -->
            <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
            <!--material icons-->
            <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
            
            <link rel="manifest" href="manifest.json">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <meta name="mobile-web-app-capable" content="yes">
            <meta name="apple-mobile-web-app-capable" content="yes">
            <meta name="apple-mobile-web-app-title" content="CECS_VIBE_APK">
            <meta name="apple-mobile-web-app-status-bar-style" content="default">
            <meta name="msapplication-starturl" content="index.php">
            <link rel="icon" sizes="192x192" href="assets/icon-192x192.png">
            <link rel="apple-touch-icon" href="assets/icon-192x192.png">
            <link rel="shortcut icon" href="assets/icon-192x192.png">
            </head>
        <body>
        <div id="loading-page-bb" style="opacity: 0; height: 100%;">
            <?php
?>


  <div class="modal fade" id="modal_recuperar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Recuperar a Senha</h5>
          <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
    <span class="meu_texto" id="txt_recuperar" style="font-size: 16px; color: #000000;  ">Preencha com seu email:</span>
    <div style="width:10px;height:5px;"></div>
    <input type="text" class="form-control" id="email_recuperar" placeholder="Email">
        </div>
        <div class="modal-footer">
    <button type="button" onclick="recuperar()" id='recuperar_btn' class="btn btn-primary">Recuperar Senha</button>
        </div>
      </div>
    </div>
  </div>



  <div class="container" id="inicio">
    <div id="base" class="classe_da_tela" style="background-color: #ffffff; height: auto; width: 100%;">
      <div id="box_login" class="classe_da_tela" style="background-color: #ffffff; height: 60%; width: 100%;">
        <div id="tela_logo" class="classe_da_tela" style="background-color: #ffffff; height: auto; width: 90%;">
          <img src="assets/VIBE.png" height="auto" width="80%" id="VIBE.png">
        </div>
        <div style="width:10px;height:40px;"></div>
        <div id="box_cadastro" class="classe_da_tela" style="background-color: #ffffff; height: 100px; width: 100%;">
          <input type="text" class="form-control" id="email_box" placeholder="Email">
          <div style="width:10px;height:20px;"></div>
          <input type="text" class="form-control" id="senha_box" placeholder="Senha">
          <div id="tela_recuperar" class="classe_da_tela" style="background-color: #ffffff; height: auto; width: 100%;">
            <span class="meu_texto" id="recuperar_lbl" style="font-size: 16px; color: #000000;  "><?php echo "<span style='color:#666666;'>".'Esqueceu a Senha?'."</span>" ; ?></span>
            <div style="width:10px;height:20px;"></div>
            <button type="button" onclick="login()" id='logar_btn' class="btn btn-success">Entrar</button>
            <div style="width:10px;height:30px;"></div>
            <div id="tela_cadastrar" class="classe_da_tela" style="background-color: #ffffff; height: auto; width: 100%;">
              <span class="meu_texto" id="cadastrar_lbl" style="font-size: 16px; color: #000000;  "><?php echo ('Não tem Cadastro? ' . "<span style='color:#ff9900;'>".'CADASTRAR'."</span>") ; ?></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<script>

        if ("serviceWorker" in navigator) {
        window.addEventListener("load", function() {
            navigator.serviceWorker.register("sw.js").then(function(registration) {
            console.log("ServiceWorker registration successful with scope: ", registration.scope);
            }, function(err) {
            console.log("ServiceWorker registration failed: ", err);
            });
        });
        }

        window.addEventListener("beforeinstallprompt", function(e) {
            console.log("beforeinstallprompt Event fired");
        });

        </script>
            <!-- bootstrap js -->
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
            <!-- jquery -->
            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.js" integrity="sha512-CX7sDOp7UTAq+i1FYIlf9Uo27x4os+kGeoT7rgwvY+4dmjqV0IuE/Bl5hVsjnQPQiTOhAX1O2r2j5bjsFBvv/A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
            <!-- firebase-app -->
            <script src="https://www.gstatic.com/firebasejs/7.21.0/firebase-app.js"></script>
            <!-- firebase-database -->
            <script src="https://www.gstatic.com/firebasejs/7.21.0/firebase-database.js"></script>
            <!-- firebase-auth -->
            <script src="https://www.gstatic.com/firebasejs/7.15.5/firebase-auth.js"></script>
            <!-- codigo javascript -->
            <script src= "login.js?v=1.0"> </script>
        </div>
        </body>
        </html>