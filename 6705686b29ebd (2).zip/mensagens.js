var lista, id_usuario, posicao, id_grupo, nome_grupo, global_lista_mensagens, user_name, Item, nome_usuario;

// Descreva esta função...
function buscar_mensagens_grupo() {
  database.ref(('mensagens/' + String(id_grupo))).orderByChild('id').limitToLast(50).on("value", function(snapshot) { listar_mensagens(snapshot.val()); });
}

// Descreva esta função...
function listar_mensagens(lista) {
  limpar_msgs();
  posicao = 0;
  if (lista) {
    global_lista_mensagens = (Object.values(lista));
    posicao = posicao + 1;
    for (var Item_index in global_lista_mensagens) {
      Item = global_lista_mensagens[Item_index];
      nome_usuario = [Item['remetente'] == id_usuario ? '' : String('<span style="font-size:14px; color:#ff6600; font-weight:bold; font-style:italic;">'+Item['user_name']+' </span>') + '<br>','<span style="font-size:18px; color:#000000; font-weight:normal; font-style:normal;">'+Item['msg']+' </span>','<br>','<span style="font-size:12px; color:#333333; font-weight:normal; font-style:normal;">'+Item['data']+' </span>'].join('');
      if (Item['remetente'] == id_usuario) {
        document.getElementById('mensagens').innerHTML += '<div class='+'msg_remetente'+' id='+'msg_rem'+' onclick="responder('+posicao+')" style="width:98%; margin:2px; padding: 5px; border-radius: 5px; box-shadow: 7px 7px 13px 0px rgba(50, 50, 50, 0.22);">'+nome_usuario+'</div>';
      } else {
        document.getElementById('mensagens').innerHTML += '<div class='+'msg_destinatario'+' id='+'msg_dest'+' onclick="responder('+posicao+')" style="width:98%; margin:2px; padding: 5px; border-radius: 5px; box-shadow: 7px 7px 13px 0px rgba(50, 50, 50, 0.22);">'+nome_usuario+'</div>';
      }
    }
  } else {
    document.getElementById('mensagens').innerHTML += '<div class='+'msg'+' id='+'msg'+' onclick="nenhuma('+0+')" style="width:98%; margin:2px; padding: 5px; border-radius: 5px; box-shadow: 7px 7px 13px 0px rgba(50, 50, 50, 0.22);">'+'Nenhuma Mensagem '+'</div>';
  }
  $(".msg_remetente").css("height", '' + "px");
  $(".msg_remetente").css("width", '80' + "%");
  $("."+'msg_remetente').css("margin-left", (window.innerWidth * (18 / 100))+"px");
  $("."+'msg_remetente').css("margin-right", 0+"px");
  $("."+'msg_remetente').css("margin-top", 10+"px");
  $("."+'msg_remetente').css("margin-bottom", 0+"px");
  $("."+'msg_destinatario').css("margin-left", 0+"px");
  $("."+'msg_destinatario').css("margin-right", 0+"px");
  $("."+'msg_destinatario').css("margin-top", 10+"px");
  $("."+'msg_destinatario').css("margin-bottom", 0+"px");
  $("."+'msg_remetente').css("padding-left", 10+"px");
  $("."+'msg_remetente').css("padding-right", 10+"px");
  $("."+'msg_remetente').css("padding-top", 10+"px");
  $("."+'msg_remetente').css("padding-bottom", 10+"px");
  $("."+'msg_destinatario').css("padding-left", 10+"px");
  $("."+'msg_destinatario').css("padding-right", 10+"px");
  $("."+'msg_destinatario').css("padding-top", 10+"px");
  $("."+'msg_destinatario').css("padding-bottom", 10+"px");
  $(".msg_destinatario").css("height", '' + "px");
  $(".msg_destinatario").css("width", '80' + "%");
  $(".msg_destinatario").css("border-radius", "20px");
  $(".msg_remetente").css("border-radius", "20px");
  let elmnt = document.getElementById('mensagens');
  elmnt.scrollIntoView(false);
}

// Descreva esta função...
function limpar_msgs() {
  function removeElementsByClass(className){
      var elements = document.getElementsByClassName(className);
      while(elements.length > 0){
          elements[0].parentNode.removeChild(elements[0]);
      }
  }
  removeElementsByClass('msg_remetente');
  function removeElementsByClass(className){
      var elements = document.getElementsByClassName(className);
      while(elements.length > 0){
          elements[0].parentNode.removeChild(elements[0]);
      }
  }
  removeElementsByClass('msg_destinatario');
}


//feito com bootblocks.com.br
  $("#"+'mensagens').css("padding-left", 0+ "px");
  $("#"+'mensagens').css("padding-right", 0+ "px");
  $("#"+'mensagens').css("padding-top", 60+ "px");
  $("#"+'mensagens').css("padding-bottom", 100+ "px");
  $("#"+'subtela_mensagens').css("padding-left", 0+ "px");
  $("#"+'subtela_mensagens').css("padding-right", 0+ "px");
  $("#"+'subtela_mensagens').css("padding-top", 0+ "px");
  $("#"+'subtela_mensagens').css("padding-bottom", 50+ "px");
  $("#"+'lbl_tela').css("padding-left", 20+ "px");
  $("#"+'lbl_tela').css("padding-right", 0+ "px");
  $("#"+'lbl_tela').css("padding-top", 0+ "px");
  $("#"+'lbl_tela').css("padding-bottom", 0+ "px");
  $("#cabecalho").css("display", "flex");
  $("#cabecalho").css("align-items", "center");

//feito com bootblocks.com.br
  firebase.initializeApp({
  apiKey: 'AIzaSyDyI6aQJoTjS-SOlvcszzdSEX7otO-v7io',
  authDomain: 'com.karlrocha.cecsvive',
  databaseURL: 'https://bate-papo-aaf12-default-rtdb.firebaseio.com',
  projectId: 'cecs vibe papo',
  storageBucket: 'gs://bate-papo-aaf12.appspot.com',
  messagingSenderId: '745965682653',
  appId: '1:745965682653:android:fadd64d3b3556a737f8034'
  });
  const database = firebase.database();
  id_usuario = localStorage.getItem('user_id') || '';
  id_grupo = localStorage.getItem('id_grupo') || '';
  nome_grupo = localStorage.getItem('nome_grupo') || '';
  user_name = localStorage.getItem('user_name') || '';
  $("#lbl_tela").html(nome_grupo);

//feito com bootblocks.com.br
  document.getElementById('cabecalho').style.position = "fixed";
  document.getElementById('cabecalho').style.top = "0px";
  document.getElementById('cabecalho').style.left = "0";
  document.getElementById('cabecalho').style.right = "0";
  document.getElementById('cabecalho').style.zIndex = "20";
  document.getElementById('nova_msg').style.position = "fixed";
  document.getElementById('nova_msg').style.bottom = "0px";
  document.getElementById('nova_msg').style.left = "0";
  document.getElementById('nova_msg').style.right = "0";
  document.getElementById('nova_msg').style.zIndex = "20";
  $("#"+'nova_msg').css("margin-left", 0+ "px");
  $("#"+'nova_msg').css("margin-right", 0+ "px");
  $("#"+'nova_msg').css("margin-top", 0+ "px");
  $("#"+'nova_msg').css("margin-bottom", 10+ "px");
  $("#"+'nova_msg').css("padding-left", 0+ "px");
  $("#"+'nova_msg').css("padding-right", 10+ "px");
  $("#"+'nova_msg').css("padding-top", 0+ "px");
  $("#"+'nova_msg').css("padding-bottom", 0+ "px");
  $("#"+'card_msg').css("padding-left", 0+ "px");
  $("#"+'card_msg').css("padding-right", 0+ "px");
  $("#"+'card_msg').css("padding-top", 0+ "px");
  $("#"+'card_msg').css("padding-bottom", 0+ "px");
  document.getElementById('msg-box').style.border = 0 + "px solid " + "#cccccc";
  $("#nova_msg").css("display", "flex");
  $("#nova_msg").css("align-items", "center");
  $("#"+'enviar_msg').css("margin-left", 0+ "px");
  $("#"+'enviar_msg').css("margin-right", 10+ "px");
  $("#"+'enviar_msg').css("margin-top", 3+ "px");
  $("#"+'enviar_msg').css("margin-bottom", 0+ "px");
  $("#msg-box").css("border-radius", "15px");
  $("#card_msg").css("border-radius", "15px");
  $("#nova_msg").css("background-color", "rgba(0, 0, 0, 0)");

//feito com bootblocks.com.br
  firebase.auth().onAuthStateChanged(function(user) {
  if (user) {
    if (!id_usuario) {
      window.location.href = "login.php";} else {
      buscar_mensagens_grupo();
    }

  } else {
    window.location.href = "login.php";
  }
  });

$(document).on("click", "#enviar_msg", function(){
});

        $(document).ready(function(){
            $("#loading-page-bb").css("opacity", "1");
        });