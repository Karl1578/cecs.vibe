var nome_arquivo, url, lista_grupos, posicao, nome_grupo, id_grupo, id_usuario, imagem_selecionada, nome_grupo_salvar, user_name, global_lista_grupos, Item, msg_piloto, data_msg;

// Descreva esta função...
function comprimir(nome_arquivo) {
  nome_arquivo = 'gruposThumb/' + String(nome_arquivo);
  firebase_storage_upload_base64(nome_arquivo, upload_ok, (jic.compress(document.getElementById('previa_grupo'), 50, 'jpg').src));
}

// Descreva esta função...
function criar_grupo() {
  if ($("#nome_grupo").val()) {
    if (imagem_selecionada) {
      id_grupo = [id_usuario,'-',new Date().getDate(),new Date().getHours(),new Date().getMinutes(),new Date().getSeconds(),new Date().getMilliseconds()].join('');
      comprimir(id_grupo);
    } else {
      Swal.fire('Selecione uma Imagem para o Grupo!');
    }
  } else {
    Swal.fire('Nome não pode ser vazio');
  }
}

// Descreva esta função...
function upload_ok(url) {
  nome_grupo = $("#nome_grupo").val();
  $("#"+'img_saida').attr("src", url);
  $("#modal_novo_grupo").modal("hide");
  database.ref(('grupos/' + String(id_grupo))).set({id:id_grupo, nome:nome_grupo, imagem:url, ultima_msg:'Nenhuma Mensagem'});
  msg_piloto = [new Date().getFullYear(),(new Date().getMonth() + 1) < 10 ? String(0) + String(new Date().getMonth() + 1) : (new Date().getMonth() + 1),(new Date().getDate()) < 10 ? String(0) + String(new Date().getDate()) : (new Date().getDate()),(new Date().getHours()) < 10 ? String(0) + String(new Date().getHours()) : (new Date().getHours()),(new Date().getMinutes()) < 10 ? String(0) + String(new Date().getMinutes()) : (new Date().getMinutes()),(new Date().getSeconds()) < 10 ? String(0) + String(new Date().getSeconds()) : (new Date().getSeconds())].join('');
  data_msg = [new Date().toLocaleDateString(),' - ',new Date().toLocaleTimeString()].join('');
  database.ref((['mensagens/',id_grupo,'/',msg_piloto].join(''))).set({id:msg_piloto, msg:'Bem Vindo!', remetente:id_usuario, data:data_msg, user_name:user_name});
  $("#nome_grupo").val('');
  imagem_selecionada = false;
  $("#"+'previa_grupo').attr("src", 'assets/upload.png');
  Swal.fire('Novo Grupo adicionado!');
  buscar_todos_os_grupos();
}

// Descreva esta função...
function sair() {
  firebase.auth().signOut();
  var clock = setInterval(nova_tela, 1000);
}

// Descreva esta função...
function nova_tela() {
  window.location.href = "login.php";}

// Descreva esta função...
function buscar_todos_os_grupos() {
  database.ref('grupos').once("value").then(function(snapshot) {
  if (snapshot.exists()) {
  listar_grupos(snapshot.val());
  } else {
  listar_grupos([]);
  }
  });
}

// Descreva esta função...
function listar_grupos(lista_grupos) {
  function removeElementsByClass(className){
      var elements = document.getElementsByClassName(className);
      while(elements.length > 0){
          elements[0].parentNode.removeChild(elements[0]);
      }
  }
  removeElementsByClass('itens_grupo');
  posicao = 0;
  global_lista_grupos = (Object.values(lista_grupos));
  for (var Item_index in global_lista_grupos) {
    Item = global_lista_grupos[Item_index];
    posicao = posicao + 1;
    var card = '<div onclick="abrir_grupo('+posicao+')" class="itens_grupo" id="'+posicao+'" style="width:98%; margin:2px; padding: 5px; border-radius: 5px; box-shadow: 7px 7px 13px 0px rgba(50, 50, 50, 0.22);">'
    card += '<div class="row">'
    card += '<div class="col-4">'
    card += '<img class="imagem_itens_grupo" id="imagem_itens_grupo" style="width:50px; height:50px;" src="'+Item['imagem']+'" alt="imagem">'
    card += '</div>'
    card += '<div class="col-8">'
    card += '<span class="titulo_itens_grupo" id="titulo_itens_grupo" style="font-weight: bold; font-size: 16px">'+Item['nome']+'</span><br>'
    card += '<span class="subtitulo_itens_grupo" id="subtitulo_itens_grupo" style="font-size: 13px">'+Item['ultima_msg']+'</span><br>'
    card += '<span class="texto_adicional_itens_grupo" id="texto_adicional_itens_grupo" style="font-size: 13px">'+''+'</span>'
    card += '</div>'
    card += '</div>'
    card +=' </div>'
    document.getElementById("lista_grupos").innerHTML += card;
  }
}

// Descreva esta função...
function buscar_mensagens_grupo() {
}

// Descreva esta função...
function abrir_grupo(posicao) {
  id_grupo = (global_lista_grupos[(posicao - 1)])['id'];
  nome_grupo_salvar = (global_lista_grupos[(posicao - 1)])['nome'];
  localStorage.setItem('id_grupo',id_grupo);
  localStorage.setItem('nome_grupo',nome_grupo_salvar);
  window.location.href = "mensagens.php";}


$(document).on("click", "#novo_btn", function(){
  $("#modal_novo_grupo").modal("show");
});

//feito com bootblocks.com.br
  firebase.initializeApp({
  apiKey: 'AIzaSyDyI6aQJoTjS-SOlvcszzdSEX7otO-v7io',
  authDomain: 'com.karlrocha.cecsvive',
  databaseURL: 'https://bate-papo-aaf12-default-rtdb.firebaseio.com',
  projectId: 'cecs vibe papo',
  storageBucket: 'gs://bate-papo-aaf12.appspot.com',
  messagingSenderId: '745965682653',
  appId: '1:745965682653:android:fadd64d3b3556a737f8034'
  });
  const database = firebase.database();
  id_usuario = localStorage.getItem('user_id') || '';
  user_name = localStorage.getItem('user_name') || '';
  imagem_selecionada = false;

$(document).on("click", "#previa_grupo", function(){
  document.getElementById('seletor_previa').click();
});

//feito com bootblocks.com.br
  $("#"+'seletor_previa').hide();
  $("#"+'lbl_tela').css("margin-left", 20+ "px");
  $("#"+'lbl_tela').css("margin-right", 0+ "px");
  $("#"+'lbl_tela').css("margin-top", 0+ "px");
  $("#"+'lbl_tela').css("margin-bottom", 0+ "px");
  $("#cabecalho").css("display", "flex");
  $("#cabecalho").css("align-items", "center");

//feito com bootblocks.com.br
  $("#novo_btn").css("left", ((window.innerWidth * (100 / 100)) - 60)+"px");
  $("#novo_btn").css("top", ((window.innerHeight * (100 / 100)) - 60)+"px");
  $("#novo_btn").css("z-index", "10000");
  $("#novo_btn").css("position", "fixed");
  $("#novo_btn").css("display", "block");

$("#seletor_previa").change(function(){
  $("#"+'previa_grupo').attr("src", (URL.createObjectURL($(this).prop("files")[0])));
  imagem_selecionada = true;
});

//feito com bootblocks.com.br
  firebase.auth().onAuthStateChanged(function(user) {
  if (user) {
    if (!id_usuario) {
      window.location.href = "login.php";} else {
      buscar_todos_os_grupos();
    }

  } else {
    window.location.href = "login.php";
  }
  });
function firebase_storage_upload_base64(file_name, function_success, file) {
                let arquivo = file;
                
                //upload file
                let storage = firebase.storage();
                let storageRef = storage.ref();
                //nome do arquivo
                let name = file_name;
                //cria um arquivo com o nome
                let fileRef = storageRef.child(name);
                //faz o upload do arquivo
                let uploadTask = fileRef.putString(arquivo, "data_url");
                //monitora o progresso do upload
                uploadTask.on("state_changed", function(snapshot) {
                }, function(error) {
                  console.log(error);
                }, function() {
                  // Handle successful uploads on complete
                  uploadTask.snapshot.ref.getDownloadURL().then(function(downloadURL) {
                    function_success(downloadURL);
                  });
                });
              };
        $(document).ready(function(){
            $("#loading-page-bb").css("opacity", "1");
        });