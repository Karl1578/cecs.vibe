// Descreva esta função...
function abrir_tela() {
  window.location.href = "login.php";}


//feito com bootblocks.com.br
  document.getElementById('inicio').style.height = (window.innerHeight * (100 / 100)) + "px";
  document.getElementById('inicio').style.width = '100' + "%";
  $("#inicio").css("display", "flex");
  $("#inicio").css("align-items", "center");
  $("#inicio").css("display", "flex");
  $("#inicio").css("justify-content", "center");
  $("#"+'logo_img').fadeOut(2000);
  var temp = setInterval(abrir_tela, 2000);

//feito com bootblocks.com.br

        $(document).ready(function(){
            $("#loading-page-bb").css("opacity", "1");
        });