var id_usuario, email, senha, senha_2, user_name;

// Descreva esta função...
function cadastrar() {
  email = $("#email_box").val();
  senha = $("#senha_box").val();
  senha_2 = $("#senha_box_2").val();
  if (!email.length) {
    Swal.fire('Preencha com seu Email');
  } else {
    if (!senha.length) {
      Swal.fire('Preencha com sua Senha');
    } else {
      if (senha != senha_2) {
        Swal.fire('Senhas são diferentes!');
      } else {
        user_name = email.split('@')[0];
        localStorage.setItem('user_name',user_name);
        firebase.auth().createUserWithEmailAndPassword(email, senha).then(function( id_usuario ) {
        id_usuario = id_usuario.user.uid;
        cadastro_ok(id_usuario);
        })
        .catch(function(error) {
        var errorMessage = error.message;
        firebaseError(errorMessage);
        });
      }
    }
  }
}

// Descreva esta função...
function cadastro_ok(id_usuario) {
  localStorage.setItem('user_id',id_usuario);
  Swal.fire('Cadastrado com sucesso!');
  var temp = setInterval(nova_tela, 1000);
}

// Descreva esta função...
function nova_tela() {
  window.location.href = "principal.php";}


//feito com bootblocks.com.br
  firebase.initializeApp({
  apiKey: 'AIzaSyDyI6aQJoTjS-SOlvcszzdSEX7otO-v7io',
  authDomain: 'com.karlrocha.cecsvive',
  databaseURL: 'https://bate-papo-aaf12-default-rtdb.firebaseio.com',
  projectId: 'cecs vibe papo',
  storageBucket: 'gs://bate-papo-aaf12.appspot.com',
  messagingSenderId: '745965682653',
  appId: '1:745965682653:android:fadd64d3b3556a737f8034'
  });
  const database = firebase.database();

//feito com bootblocks.com.br

$(document).on("click", "#logar_lbl", function(){
  window.location.href = "login.php";});

//feito com bootblocks.com.br
  $("#tela_logo").css("display", "flex");
  $("#tela_logo").css("justify-content", "center");
  $("#tela_text_box").css("display", "flex");
  $("#tela_text_box").css("justify-content", "center");
  $("#logar_btn").css("height", "40px");
  $("#logar_btn").css("width", "100%");
  $("#tela_cadastrar").css("display", "flex");
  $("#tela_cadastrar").css("justify-content", "center");
  $("#"+'tela_logo').css("margin-left", 0+ "px");
  $("#"+'tela_logo').css("margin-right", 0+ "px");
  $("#"+'tela_logo').css("margin-top", 110+ "px");
  $("#"+'tela_logo').css("margin-bottom", 0+ "px");

        $(document).ready(function(){
            $("#loading-page-bb").css("opacity", "1");
        });