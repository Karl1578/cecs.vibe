var id_usuario, email_recuperar, email, senha, user_name;

// Descreva esta função...
function recuperar() {
  email_recuperar = $("#email_recuperar").val();
  if (!email_recuperar.length) {
    Swal.fire('Preencha com seu Email');
  } else {
    $("#modal_recuperar").modal("hide");
    firebase.auth().sendPasswordResetEmail(email_recuperar).then(function() {
    recuperar_ok();
    })
    .catch(function(error) {
    var errorCode = error.code;
    var errorMessage = error.message;
    firebaseError(errorMessage);
    });
  }
}

// Descreva esta função...
function recuperar_ok() {
  Swal.fire('Um link para recuperar sua senha foi enviado para seu email!');
}

// Descreva esta função...
function login() {
  email = $("#email_box").val();
  senha = $("#senha_box").val();
  if (!email.length) {
    Swal.fire('Preencha com o Email!');
  } else {
    if (!senha.length) {
      Swal.fire('Preencha com a Senha!');
    } else {
      user_name = email.split('@')[0];
      localStorage.setItem('user_name',user_name);
      firebase.auth().signInWithEmailAndPassword(email, senha).then(function( id_usuario ) {
      id_usuario = id_usuario.user.uid;
      login_ok(id_usuario);
      })
      .catch(function(error) {
      var errorCode = error.code;
      var errorMessage = error.message;
      firebaseError(errorMessage);
      });
    }
  }
}

// Descreva esta função...
function login_ok(id_usuario) {
  localStorage.setItem('user_id',id_usuario);
  window.location.href = "principal.php";}


//feito com bootblocks.com.br
  firebase.initializeApp({
  apiKey: 'AIzaSyDyI6aQJoTjS-SOlvcszzdSEX7otO-v7io',
  authDomain: 'com.karlrocha.cecsvive',
  databaseURL: 'https://bate-papo-aaf12-default-rtdb.firebaseio.com',
  projectId: 'cecs vibe papo',
  storageBucket: 'gs://bate-papo-aaf12.appspot.com',
  messagingSenderId: '745965682653',
  appId: '1:745965682653:android:fadd64d3b3556a737f8034'
  });
  const database = firebase.database();

$(document).on("click", "#recuperar_lbl", function(){
  $("#modal_recuperar").modal("show");
  console.log('modal_recuperar');
});

//feito com bootblocks.com.br
  $("#base").css("display", "flex");
  $("#base").css("align-items", "center");
  document.getElementById('base').style.height = (window.innerHeight * (100 / 100)) + "px";
  document.getElementById('base').style.width = '100' + "%";
  $("#tela_logo").css("display", "flex");
  $("#tela_logo").css("justify-content", "center");
  $("#tela_recuperar").css("text-align", "right");
  $("#tela_cadastrar").css("display", "flex");
  $("#tela_cadastrar").css("justify-content", "center");
  $("#logar_btn").css("height", "40px");
  $("#logar_btn").css("width", "100%");
  $("#tela_text_box").css("display", "flex");
  $("#tela_text_box").css("justify-content", "center");

//feito com bootblocks.com.br

$(document).on("click", "#cadastrar_lbl", function(){
  window.location.href = "cadastro.php";});

//feito com bootblocks.com.br
  firebase.auth().onAuthStateChanged(function(user) {
  if (user) {
    window.location.href = "principal.php";
  } else {

  }
  });

        $(document).ready(function(){
            $("#loading-page-bb").css("opacity", "1");
        });